<!DOCTYPE html>
<html lang="en">
<head>
<title>Saphire Media Services</title>
<style>table, th, td {
  border: 1px solid black;
  border-collapse:collapse ;
}
th, td {
  padding: 1px;
  text-align: left;    
}
</style>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="css/fullcalendar.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" href="css/jquery.gritter.css" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
</head>
<body>

<!--Header-part-->
<div id="header">
  <h1><a href="dashboard.html">Saphire Media Services</a></h1>
</div>
<!--close-Header-part--> 


<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>  <span class="text">Welcome User</span><b class="caret"></b></a>
      <ul class="dropdown-menu">
        <li><a href="#"><i class="icon-user"></i> My Profile</a></li>
        <li class="divider"></li>
        <li><a href="#"><i class="icon-check"></i> My Tasks</a></li>
        <li class="divider"></li>
        <li><a href="logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
    <li class=""><a title="" href="logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
  </ul>
</div>
<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li id="search"><input style="width:160px" type="text"  placeholder="Search here..."/><button type="submit" class="middle" title="Search"><i class="icon-search icon-white"></i></button></li>
	<li><a href="home.html"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
	<li><a href="admin.html"><i class="icon icon-user-md"></i> <span>Admin panel</span></a> </li>
    <li> <a href="charts.html"><i class="icon icon-signal"></i> <span>CHARTS AND GRAPH</span></a> </li>
    <li> <a href="emp.php"><i class="icon icon-group"></i> <span>EMPLOYEE</span></a> </li>
    <li><a href="stock.html"><i class="icon icon-inbox"></i> <span>INVENTORY</span></a></li>
    <li class="active"><a href="acc.html"><i class="icon icon-th"></i> <span>ACCOUNT</span></a></li>
	<li> <a href="order.html"> <i class="icon-pencil"></i>ORDERS</a> </li>
    <li><a href="cus.php"><i class="icon icon-user"></i> <span>CUSTOMER</span></a></li>
    <li><a href="rep.html"><i class="icon icon-th-list"></i> <span>REPORTS</span></a></li>
    <li><a href="ava.php"><i class="icon icon-check"></i> <span>AVAILABILITY</span></a></li>
    <li> <a href="trans.html"><i class="icon icon-truck"></i> <span>TRANSPORT AND PACKAGE</span></a></li>
	<li> <a href="leave.html"><i class="icon icon-info-sign"></i> <span>FORMS</span></a></li>
	</ul>
</div>
<!--sidebar-menu-->
<div id="active">
<!--breadcrumbs-->
<form action="#" method="get" class="form-horizontal">
<div class="row-fluid">
  <div id="content">
  <div id="content-header">
    <div id="breadcrumb"><a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#" class="current">Account</a></div>

		  <div class="widget-box">
          <div class="widget-title">
            <ul class="nav nav-tabs">
              <li class="active"><a data-toggle="tab" href="#tab1">Salary for employee</a></li>
              <li><a data-toggle="tab" href="#tab2">Customer transaction</a></li>
            <li><a data-toggle="tab" href="#tab3">Customer invoice</a></li>  
			</ul>
          </div>
          <div class="widget-content tab-content">
            <div id="tab1" class="tab-pane active">
              <label>salary for employee</label>
			 
<table style="width:10%">
  <tr>
    <th>Designation</th>
    <th>name</th> 
    <th>Salary</th>
  </tr>
  	
  
  <?php
   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
    $dbname="erp";
   
   $conn = mysql_connect($dbhost, $dbuser, $dbpass);
   
   if(! $conn ) {
      die('Could not connect: ' . mysql_error());
   }
   
   $sql = 'SELECT Name,Designation,Salary FROM employeedetailes';
   mysql_select_db('erp');
   $retval = mysql_query( $sql, $conn );
   
   if(! $retval ) {
      die('Could not get data: ' . mysql_error());
   }
   
   while($row = mysql_fetch_array($retval, MYSQL_ASSOC)) {
	   
	   echo "<tr><td>".$row["Designation"]."</td><td>".$row["Name"]."</td><td>".$row["Salary"]."</td></tr>";
    //  echo "ProductName :{$row['Quantity']}  <br> ";
        
       //  mysql_close($conn);  
   }
   
  
?>
</table>	
            
			  </div>
            <div id="tab2" class="tab-pane content">
              <label>customer details</label>
			 
<table style="width:10%">
  <tr>
    <th>id</th>
    <th>name</th> 
    <th>product</th>
	    <th>price</th>

  </tr>
  
  <?php
   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
    $dbname="erp";
   
   $conn = mysql_connect($dbhost, $dbuser, $dbpass);
   
   if(! $conn ) {
      die('Could not connect: ' . mysql_error());
   }
   
   $sql = 'SELECT customersize,customername,product,totalamount FROM customerorder';
   mysql_select_db('erp');
   $retval = mysql_query( $sql, $conn );
   
   if(! $retval ) {
      die('Could not get data: ' . mysql_error());
   }
   
   while($row = mysql_fetch_array($retval, MYSQL_ASSOC)) {
	   
	   echo "<tr><td>".$row["customersize"]."</td><td>".$row["customername"]."</td><td>".$row["product"]."</td><td>".$row["totalamount"]."</td></tr>";
    //  echo "ProductName :{$row['Quantity']}  <br> ";
        
       //  mysql_close($conn);  
   }
   
  
?>
</table>	
            
	  </div>
	 <div id="tab3" class="tab-pane content">
      <label>customer invoice</label>
	  <table style="width:10%">
  <tr>
    <th>product</th>
    <th>product id</th>
    <th>amount</th>
    <th>gst</th> 
	
	
    <th></th>
  </tr>

 <?php
   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
    $dbname="erp";
   
   $conn = mysql_connect($dbhost, $dbuser, $dbpass);
   
   if(! $conn ) {
      die('Could not connect: ' . mysql_error());
   }
   
   $sql = 'SELECT ProductName,Quantity,Price,Gst FROM rawmaterial';
   mysql_select_db('erp');
   $retval = mysql_query( $sql, $conn );
   
   if(! $retval ) {
      die('Could not get data: ' . mysql_error());
   }
   
   while($row = mysql_fetch_array($retval, MYSQL_ASSOC)) {
	   
	   echo "<tr><td>".$row["ProductName"]."</td><td>".$row["Quantity"]."</td><td>".$row["Price"]."</td><td>".$row["Gst"]."</td></tr>";
    //  echo "ProductName :{$row['Quantity']}  <br> ";
        
       //  mysql_close($conn);  
   }
   
  
?>
</table>
<br>


</form>
</div>

<script>
function myCreateFunction() {
  var table = document.getElementById("myTable");
  var row = table.insertRow(0);
  var cell1 = row.insertCell(0);
  var cell2 = row.insertCell(1);
  cell1.innerHTML = "NEW CELL1";
  cell2.innerHTML = "NEW CELL2";
}

function myDeleteFunction() {
  document.getElementById("myTable").deleteRow(0);
}
</script>
  </div>


<script src="js/excanvas.min.js"></script> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script>

<script type="text/javascript">
  // This function is called from the pop-up menus to transfer to
  // a different page. Ignore if the value returned is a null string:
  function goPage (newURL) {

      // if url is empty, skip the menu dividers and reset the menu selection to default
      if (newURL != "") {
      
          // if url is "-", it is this page -- reset the menu:
          if (newURL == "-" ) {
              resetMenu();            
          } 
          // else, send page to designated URL            
          else {  
            document.location.href = newURL;
          }
      }
  }

// resets the menu selection upon entry to this page:
function resetMenu() {
   document.gomenu.selector.selectedIndex = 2;
}
</script>
</body>
</html>
