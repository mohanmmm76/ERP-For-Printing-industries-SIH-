<?php $product=$_POST["product"];$print_type=$_POST["print_type"];$size=$_POST["size"];$cost=$_POST["cost"];

// Create connection
$conn=mysqli_connect("localhost","root","","erp");
echo "u is lucky this time";

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$conn=mysqli_connect("localhost","root","","erp");
if (mysqli_select_db($conn,'erp'))
{
echo "not select db";
}



$sql = "INSERT INTO costupdate (product,print_type,size,cost)
VALUES ('$product','$print_type','$size','$cost')";
if ($conn->query($sql) === TRUE) {
    echo "done";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

header("refresh:1; url=stock.html");


?>
