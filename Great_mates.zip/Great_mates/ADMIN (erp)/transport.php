<?php $Packageid=$_POST["Packageid"];
$Fromplace=$_POST["Fromplace"];
$Toplace=$_POST["Toplace"];
$Date=$_POST["Date"];
$Amount=$_POST["Amount"];
// Create connection
$conn=mysqli_connect("localhost","root","","erp");
//echo "u is lucky this time";

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$conn=mysqli_connect("localhost","root","","erp");
if (mysqli_select_db($conn,'erp'))
{
//echo "not select db";
}



$sql = "INSERT INTO packaging(Packageid,Fromplace,Toplace,Date,Amount)
VALUES ('$Packageid','$Fromplace','$Toplace','$Date','$Amount')";
if ($conn->query($sql) === TRUE) {
    echo "done";
} else {
  //  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

header("refresh:1; url=stock.html");


?>
