
<?php $ProductName=$_POST["ProductName"];$Quantity=$_POST["Quantity"];$Price=$_POST["Price"];$Gst=$_POST["Gst"];

// Create connection
$conn=mysqli_connect("localhost","root","","erp");
echo "u is lucky this time";

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$conn=mysqli_connect("localhost","root","","erp");
if (mysqli_select_db($conn,'erp'))
{
echo "not select db";
}



$sql = "INSERT INTO rawmaterial (ProductName,Quantity,Price,Gst)
VALUES ('$ProductName','$Quantity','$Price','$Gst')";
if ($conn->query($sql) === TRUE) {
    echo "done";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

header("refresh:1; url=stock.html");


?>
