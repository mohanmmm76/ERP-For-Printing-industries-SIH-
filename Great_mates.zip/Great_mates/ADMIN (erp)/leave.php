
<?php $Customername=$_POST["Customername"];$customerid=$_POST["customerid"];$customerDes=$_POST["customerDes"];$customerphone=$_POST["customerphone"];$customermail=$_POST["customermail"];$customerReason= $_POST["customerReason"];$date1= $_POST["date1"];$date2= $_POST["date2"];

// Create connection
$conn=mysqli_connect("localhost","root","","erp");
echo "u is lucky this time";

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$conn=mysqli_connect("localhost","root","","erp");
if (mysqli_select_db($conn,'erp'))
{
echo "not select db";
}



$sql = "INSERT INTO leavefrom (Customername,customerid,customerDes,customerphone,customermail,customerReason,date1,date2)
VALUES ('$Customername','$customerid','$customerDes','$customerphone','$customermail','$customerReason','$date1','$date2')";
if ($conn->query($sql) === TRUE) {
    echo "done";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

header("refresh:1; url=leave.html");


?>
