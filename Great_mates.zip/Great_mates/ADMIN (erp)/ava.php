<!DOCTYPE html>
<html lang="en">
<head>
<title>Saphire Media Services</title>
<meta charset="UTF-8" />
<style>       
 table {          font-family: arial, sans-serif;          border-collapse: collapse;          width: 100%;        }  
      td, th {          border: 1px solid #dddddd;          text-align: left;          padding: 8px;        }   
     tr:nth-child(even) {          background-color: #dddddd;        }   
 </style>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="css/fullcalendar.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link rel="stylesheet" href="css/jquery.gritter.css" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

<!--Header-part-->
<div id="header">
  <h1><a href="dashboard.html">Saphire Media Services</a></h1>
</div>
<!--close-Header-part--> 


<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>  <span class="text">Welcome User</span><b class="caret"></b></a>
      <ul class="dropdown-menu">
        <li><a href="#"><i class="icon-user"></i> My Profile</a></li>
        <li class="divider"></li>
        <li><a href="#"><i class="icon-check"></i> My Tasks</a></li>
        <li class="divider"></li>
        <li><a href="logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
    <li class=""><a title="" href="logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
  </ul>
</div>
<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li id="search"><input style="width:160px" type="text"  placeholder="Search here..."/><button type="submit" class="middle" title="Search"><i class="icon-search icon-white"></i></button></li>
	<li><a href="home.html"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
	<li><a href="admin.html"><i class="icon icon-user-md"></i> <span>Admin panel</span></a> </li>
    <li> <a href="charts.html"><i class="icon icon-signal"></i> <span>CHARTS AND GRAPH</span></a> </li>
    <li> <a href="emp.php"><i class="icon icon-group"></i> <span>EMPLOYEE</span></a> </li>
    <li><a href="stock.html"><i class="icon icon-inbox"></i> <span>INVENTORY</span></a></li>
    <li><a href="acc.php"><i class="icon icon-th"></i> <span>ACCOUNT</span></a></li>
	<li> <a href="order.html"> <i class="icon-pencil"></i>ORDERS</a> </li>
    <li><a href="cus.php"><i class="icon icon-user"></i> <span>CUSTOMER</span></a></li>
    <li><a href="rep.html"><i class="icon icon-th-list"></i> <span>REPORTS</span></a></li>
    <li class="active"><a href="ava.php"><i class="icon icon-check"></i> <span>AVAILABILITY</span></a></li>
    <li> <a href="trans.html"><i class="icon icon-truck"></i> <span>TRANSPORT AND PACKAGE</span></a></li>
	<li> <a href="leave.html"><i class="icon icon-info-sign"></i> <span>FORMS</span></a></li>
	</ul>
</div>
<!--sidebar-menu-->
<div id="content">
<div id="content-header">
  <div id="breadcrumb"> <a href="home.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#" class="tip-bottom">Availability</a></div>
  <h1>AVAILABILITY</h1>
</div>
<div class="container-fluid">
  <hr>
  <div class="row-fluid">
    <div class="span6">
	 <div id="tab3" class="tab-pane content">
      <label></label>
	 
<?php   
 $dbHost = "localhost";    
$dbUser = "root";  
  $dbPass = "";   
 $dbName = "erp";  
  $mysqlConnection = mysql_connect($dbHost, $dbUser, $dbPass); 
   if(!$mysqlConnection){        die( mysql_error());    } 
   $sql= " SELECT ProductName, Quantity, Price, Gst FROM  rawmaterial ";  
  mysql_select_db("erp");    $data = mysql_query($sql, $mysqlConnection);  
  if(!$data){        die(mysql_error());    }
?>
<table>   
     <tr>          
  <th>Product Name</th>   
         <th>Quantity</th>      
      <th>Price</th>      
      <th>GST</th>        
 </tr>    
    <?php     
       while($row = mysql_fetch_array($data, MYSQL_ASSOC)){      
          $status = "";             
   	   $qty = (int)$row['Quantity'];     //echo $qty; exit;
           if($qty <= 10){         
           $status = "&nbsp;&nbsp;<i class='fa fa-warning' style='color:orange'></i>";
                  if($qty <= 5)             
           $status = "&nbsp;&nbsp;<i class='fa fa-warning' style='color:red'></i>";
                }
	  if($row['ProductName'])      
          echo "<tr><td>".$row['ProductName']."</td><td>".$row['Quantity'] . $status ."</td><td>".$row['Price']."</td><td>".$row['Gst']."</td></tr>";            }        ?>    </table>
</div></div>
</div>
</div>
</div>
              
      


<script type="text/javascript">
  // This function is called from the pop-up menus to transfer to
  // a different page. Ignore if the value returned is a null string:
  function goPage (newURL) {

      // if url is empty, skip the menu dividers and reset the menu selection to default
      if (newURL != "") {
      
          // if url is "-", it is this page -- reset the menu:
          if (newURL == "-" ) {
              resetMenu();            
          } 
          // else, send page to designated URL            
          else {  
            document.location.href = newURL;
          }
      }
  }

// resets the menu selection upon entry to this page:
function resetMenu() {
   document.gomenu.selector.selectedhome = 2;
}
</script>
</body>
</html>
