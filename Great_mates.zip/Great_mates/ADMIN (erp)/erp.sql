-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 24, 2019 at 06:09 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `erp`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `s_no` int(100) NOT NULL,
  `InitialInvestment` varchar(100) NOT NULL,
  `MonthlyExpense` varchar(100) NOT NULL,
  `Monthlyincome` varchar(100) NOT NULL,
  `GstAmount` varchar(100) NOT NULL,
  `AnnualIncome` varchar(100) NOT NULL,
  `AnnualExpense` varchar(100) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customerdetails`
--

CREATE TABLE `customerdetails` (
  `s_no` int(100) NOT NULL,
  `Customername` text NOT NULL,
  `Phno` varchar(1000) NOT NULL,
  `Address` varchar(1000) NOT NULL,
  `PreviousOrder` text NOT NULL,
  `Amount` varchar(100) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customerorder`
--

CREATE TABLE `customerorder` (
  `s_no` int(11) NOT NULL,
  `customername` text NOT NULL,
  `product` text NOT NULL,
  `desing` text NOT NULL,
  `customersize` text NOT NULL,
  `print_type` text NOT NULL,
  `Customermail` text NOT NULL,
  `Customerphone` text NOT NULL,
  `Companyinfo` text NOT NULL,
  `customeraddress` varchar(2000) NOT NULL,
  `Descriptionfield` text NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `employeedetailes`
--

CREATE TABLE `employeedetailes` (
  `s_no` int(100) NOT NULL,
  `Id` varchar(10) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Designation` varchar(100) NOT NULL,
  `Phno` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Salary` varchar(100) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `leavefrom`
--

CREATE TABLE `leavefrom` (
  `s_no` int(100) NOT NULL,
  `Customername` text NOT NULL,
  `customerid` int(100) NOT NULL,
  `customerDes` text NOT NULL,
  `customerphone` text NOT NULL,
  `customermail` varchar(100) NOT NULL,
  `customerReason` text NOT NULL,
  `date1` date NOT NULL,
  `date2` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `packaging`
--

CREATE TABLE `packaging` (
  `S_NO` int(100) NOT NULL,
  `Packageid` varchar(100) NOT NULL,
  `Fromplace` varchar(1000) NOT NULL,
  `Toplace` varchar(1000) NOT NULL,
  `Date` date NOT NULL,
  `Amount` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rawmaterial`
--

CREATE TABLE `rawmaterial` (
  `s_no` int(100) NOT NULL,
  `ProductName` text NOT NULL,
  `Quantity` varchar(100) NOT NULL,
  `Price` varchar(100) NOT NULL,
  `Gst` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rawmaterial`
--

INSERT INTO `rawmaterial` (`s_no`, `ProductName`, `Quantity`, `Price`, `Gst`) VALUES
(8, 'moha', '5', '500', '5200');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `customerdetails`
--
ALTER TABLE `customerdetails`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `customerorder`
--
ALTER TABLE `customerorder`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `employeedetailes`
--
ALTER TABLE `employeedetailes`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `leavefrom`
--
ALTER TABLE `leavefrom`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `packaging`
--
ALTER TABLE `packaging`
  ADD PRIMARY KEY (`S_NO`);

--
-- Indexes for table `rawmaterial`
--
ALTER TABLE `rawmaterial`
  ADD PRIMARY KEY (`s_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `s_no` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customerdetails`
--
ALTER TABLE `customerdetails`
  MODIFY `s_no` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customerorder`
--
ALTER TABLE `customerorder`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employeedetailes`
--
ALTER TABLE `employeedetailes`
  MODIFY `s_no` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leavefrom`
--
ALTER TABLE `leavefrom`
  MODIFY `s_no` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `packaging`
--
ALTER TABLE `packaging`
  MODIFY `S_NO` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rawmaterial`
--
ALTER TABLE `rawmaterial`
  MODIFY `s_no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
