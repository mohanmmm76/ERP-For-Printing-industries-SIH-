<?php $InitialInvestment=$_POST["InitialInvestment"];$MonthlyExpense=$_POST["MonthlyExpense"];
$Monthlyincome=$_POST["Monthlyincome"];
$GstAmount=$_POST["GstAmount"];
$AnnualIncome=$_POST["AnnualIncome"];
$AnnualExpense=$_POST["AnnualExpense"];


// Create connection
$conn=mysqli_connect("localhost","root","","erp");
//echo "u is lucky this time";

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$conn=mysqli_connect("localhost","root","","erp");
if (mysqli_select_db($conn,'erp'))
{
//echo "not select db";
}



$sql = "INSERT INTO accounts (InitialInvestment,MonthlyExpense,Monthlyincome,GstAmount,AnnualIncome,AnnualExpense)
VALUES ('$InitialInvestment','$MonthlyExpense','$Monthlyincome','$GstAmount','$AnnualIncome','$AnnualExpense')";
if ($conn->query($sql) === TRUE) {
    echo "done";
} else {
  //  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

header("refresh:1; url=stock.html");


?>
