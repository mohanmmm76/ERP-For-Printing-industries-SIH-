-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 03, 2019 at 11:17 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `erp`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `s_no` int(100) NOT NULL,
  `InitialInvestment` varchar(100) NOT NULL,
  `MonthlyExpense` varchar(100) NOT NULL,
  `Monthlyincome` varchar(100) NOT NULL,
  `GstAmount` varchar(100) NOT NULL,
  `AnnualIncome` varchar(100) NOT NULL,
  `AnnualExpense` varchar(100) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `costupdate`
--

CREATE TABLE `costupdate` (
  `product` int(11) NOT NULL,
  `print_type` text NOT NULL,
  `size` text NOT NULL,
  `cost` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customerdetails`
--

CREATE TABLE `customerdetails` (
  `s_no` int(100) NOT NULL,
  `Customername` text NOT NULL,
  `Phno` varchar(1000) NOT NULL,
  `Address` varchar(1000) NOT NULL,
  `PreviousOrder` text NOT NULL,
  `Amount` varchar(100) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customerdetails`
--

INSERT INTO `customerdetails` (`s_no`, `Customername`, `Phno`, `Address`, `PreviousOrder`, `Amount`, `Date`) VALUES
(1, 'ayyappan', '9715218680', 'vilakudi', 'nil', '1000', '2019-03-03'),
(2, 'mohankumar', '999425505', 'poondi', 'broucher', '25', '2019-03-03'),
(3, 'logu', '9025785034', 'chettipalayam', 'nill', '500', '2019-03-05');

-- --------------------------------------------------------

--
-- Table structure for table `customerorder`
--

CREATE TABLE `customerorder` (
  `unique id` int(100) NOT NULL,
  `s_no` int(11) NOT NULL,
  `customername` text NOT NULL,
  `product` text NOT NULL,
  `desing` text NOT NULL,
  `customersize` text NOT NULL,
  `print_type` text NOT NULL,
  `Customermail` text NOT NULL,
  `Customerphone` text NOT NULL,
  `Companyinfo` text NOT NULL,
  `customeraddress` varchar(2000) NOT NULL,
  `Descriptionfield` text NOT NULL,
  `Date` date NOT NULL,
  `intialamount` int(12) NOT NULL,
  `totalamount` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customerorder`
--

INSERT INTO `customerorder` (`unique id`, `s_no`, `customername`, `product`, `desing`, `customersize`, `print_type`, `Customermail`, `Customerphone`, `Companyinfo`, `customeraddress`, `Descriptionfield`, `Date`, `intialamount`, `totalamount`) VALUES
(0, 1, '', '', '', '', '', '', '', '', '', '', '0000-00-00', 0, 0),
(0, 2, '', 'flex', '', '', 'digital printing', '', '', '', '', '', '0000-00-00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `employeedetailes`
--

CREATE TABLE `employeedetailes` (
  `s_no` int(100) NOT NULL,
  `Id` varchar(10) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Designation` varchar(100) NOT NULL,
  `Phno` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Salary` varchar(100) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employeedetailes`
--

INSERT INTO `employeedetailes` (`s_no`, `Id`, `Name`, `Designation`, `Phno`, `Address`, `Salary`, `Date`) VALUES
(1, '', '', '', '', '', '', '0000-00-00'),
(2, '', '', '', '', '', '', '0000-00-00'),
(3, '16cs06', 'veera', 'manager', '9715218680', 'vilakudi', '50000', '2019-03-05'),
(4, '16cs12', 'lokesh', 'employee', '04369232705', 'krishnagiri', '20000', '2019-03-07'),
(5, '16cs11', 'logu', 'PA', '9715218679', 'thirpur', '1000', '2019-03-06');

-- --------------------------------------------------------

--
-- Table structure for table `historicaldata`
--

CREATE TABLE `historicaldata` (
  `product` varchar(100) NOT NULL,
  `print_type` varchar(100) NOT NULL,
  `size` int(100) NOT NULL,
  `orderdate` date NOT NULL,
  `deliveryDate` date NOT NULL,
  `cost` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `historicaldata`
--

INSERT INTO `historicaldata` (`product`, `print_type`, `size`, `orderdate`, `deliveryDate`, `cost`) VALUES
('flex', 'digital printing', 0, '0000-00-00', '0000-00-00', 0),
('flex', 'digital printing', 0, '0000-00-00', '0000-00-00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `leavefrom`
--

CREATE TABLE `leavefrom` (
  `s_no` int(100) NOT NULL,
  `Customername` text NOT NULL,
  `customerid` int(100) NOT NULL,
  `customerDes` text NOT NULL,
  `customerphone` text NOT NULL,
  `customermail` varchar(100) NOT NULL,
  `customerReason` text NOT NULL,
  `date1` date NOT NULL,
  `date2` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `email`, `password`) VALUES
(1, 'mohanmmm', 'moahnmmm@gmail.com', 'c1254fa990ecae4ef46ddda432d5f6a0'),
(2, 'mohanmmm', '12345@gmail.com', '67da4689386d1ff8a7515209f2a74623'),
(3, 'MMM', 'M@GMAIL.COM', 'e10adc3949ba59abbe56e057f20f883e'),
(4, 'ayyappanveera', 'ayyappanveera35@gmail.com', '3a059a17add294ce14e3c33db0c1d96c');

-- --------------------------------------------------------

--
-- Table structure for table `mechinedetaile`
--

CREATE TABLE `mechinedetaile` (
  `s.no` int(100) NOT NULL,
  `mechines` varchar(100) NOT NULL,
  `Requiredemployee` varchar(100) NOT NULL,
  `mechinestatus` varchar(100) NOT NULL,
  `MechineserviceDate` date NOT NULL,
  `Date` date NOT NULL,
  `effisiency` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `packaging`
--

CREATE TABLE `packaging` (
  `S_NO` int(100) NOT NULL,
  `Packageid` varchar(100) NOT NULL,
  `Fromplace` varchar(1000) NOT NULL,
  `Toplace` varchar(1000) NOT NULL,
  `Date` date NOT NULL,
  `Amount` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `packaging`
--

INSERT INTO `packaging` (`S_NO`, `Packageid`, `Fromplace`, `Toplace`, `Date`, `Amount`) VALUES
(1, '', '', '', '0000-00-00', ''),
(2, '', '', '', '0000-00-00', ''),
(3, '', 'rexrtcyhnj,l', '', '0000-00-00', ''),
(4, '', 'rexrtcyhnj,l', '', '0000-00-00', ''),
(5, '', 'rexrtcyhnj,l', '', '0000-00-00', ''),
(6, '', 'rexrtcyhnj,l', '', '0000-00-00', ''),
(7, '', '', '', '0000-00-00', '54156'),
(8, '', '', '', '0000-00-00', '54156');

-- --------------------------------------------------------

--
-- Table structure for table `rawmaterial`
--

CREATE TABLE `rawmaterial` (
  `s_no` int(100) NOT NULL,
  `ProductName` text NOT NULL,
  `Quantity` varchar(100) NOT NULL,
  `Price` varchar(100) NOT NULL,
  `Gst` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rawmaterial`
--

INSERT INTO `rawmaterial` (`s_no`, `ProductName`, `Quantity`, `Price`, `Gst`) VALUES
(2, 'FLEX', '5', '2500', '180'),
(3, 'flexpaper', '50', '150', '20'),
(4, 'bluelink', '20', '55', '5'),
(5, 'broucher', '11', '25', '2'),
(6, 'slovent', '15', '50', '2'),
(7, '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `customerdetails`
--
ALTER TABLE `customerdetails`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `customerorder`
--
ALTER TABLE `customerorder`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `employeedetailes`
--
ALTER TABLE `employeedetailes`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `leavefrom`
--
ALTER TABLE `leavefrom`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mechinedetaile`
--
ALTER TABLE `mechinedetaile`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `packaging`
--
ALTER TABLE `packaging`
  ADD PRIMARY KEY (`S_NO`);

--
-- Indexes for table `rawmaterial`
--
ALTER TABLE `rawmaterial`
  ADD PRIMARY KEY (`s_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `s_no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customerdetails`
--
ALTER TABLE `customerdetails`
  MODIFY `s_no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customerorder`
--
ALTER TABLE `customerorder`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `employeedetailes`
--
ALTER TABLE `employeedetailes`
  MODIFY `s_no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `leavefrom`
--
ALTER TABLE `leavefrom`
  MODIFY `s_no` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `mechinedetaile`
--
ALTER TABLE `mechinedetaile`
  MODIFY `s.no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `packaging`
--
ALTER TABLE `packaging`
  MODIFY `S_NO` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `rawmaterial`
--
ALTER TABLE `rawmaterial`
  MODIFY `s_no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
