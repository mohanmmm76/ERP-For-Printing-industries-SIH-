<?php $Customername=$_POST["Customername"];$Phno=$_POST["Phno"];$Address=$_POST["Address"];$PreviousOrder=$_POST["PreviousOrder"];$Amount=$_POST["Amount"];$Date=$_POST["Date"];

// Create connection
$conn=mysqli_connect("localhost","root","","erp");
echo "u is lucky this time";

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$conn=mysqli_connect("localhost","root","","erp");
if (mysqli_select_db($conn,'erp'))
{
echo "not select db";
}



$sql = "INSERT INTO customerdetails (Customername,Phno,Address,PreviousOrder,Amount,Date)
VALUES ('$Customername','$Phno','$Address','$PreviousOrder','$Amount','$Date')";
if ($conn->query($sql) === TRUE) {
    echo "done";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

header("refresh:1; url=stock.html");


?>
